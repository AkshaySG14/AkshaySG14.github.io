export const CHANGE_PAGE = "change_page";
export const CHANGE_SIDEBAR_ACTIVE = "change_sidebar_active";
export const CHANGE_SOURCE_CODE_COMPONENT = "change_source_code_component";